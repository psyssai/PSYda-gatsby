---
title: "[Pandas 기초]10.DataFrame의 집계(그룹핑) 함수"
category: "빅데이터분석/Pandas"
date: "2019-08-31"
tags: ["dataframe 그룹핑", "groupby", "pivot_table", "그룹"]
---

안녕하세요. PSYda입니다.

이번 포스팅에서는 DataFrame의 집계(그루핑) 함수에 대해 알아보겠습니다.

집계함수란 데이터를 몇몇의 집단으로 나누어 집단간 평균, 합계 등의 연산을 수행하는 함수를 얘기합니다.  
예를 들어 고등학교 학생 전체 성적 데이터가 있을 경우 <strong>반별</strong>로 <strong>영어성적</strong>에 대한 <strong>평균</strong>을 내거나, <strong>과목별</strong>로 학생들의 <strong>성적</strong>에 대한 평균을 내는 것과 같습니다.  
예와 같이 집계함수를 적용하기 위해서는 <strong>3가지 값</strong>이 필요하며, 그 값은 <strong><span style = "color:red">그룹할 기준</span></strong>(반별 또는 과목별), <strong><span style = "color:red">연산을 수행할 값</span></strong>(영어성적), <strong><span style = "color:red">연산 함수</span></strong>(평균) 입니다.

이번 포스팅에서 소개할 내용을 요약하면 아래와 같습니다.

<div id = "summary">
<ul>
    <li><strong><span style = "color:red">groupby 함수</span></strong>을 사용한 DataFrame 집계</li>
    <li><strong><span style = "color:red">pivot_table 함수</span></strong>를 사용한 DataFrame 집계</li>
</ul>
</div>

실습에 사용한 데이터는 fifa19에 등장하는 축구선수들의 능력치 데이터입니다.  
데이터는 아래에서 다운로드 받을 수 있습니다.
[##_File|t/cfile@9997B8475D6BD0CE23|filename="Ch10_1_fifaStats2.csv" size="다운로드"|_##]

# 9. DataFrame의 집계함수

DataFrame을 집계할 수 있는 두 개의 함수

- <span class ="hlblock">groupby</span>
- <span class ="hlblock">pivot_table</span>

## 9.1 groupby 함수

groupby 함수를 사용한 집계 연산은 두 단계로 이루어짐

- DataFrame을 <strong><span style = "color:red">그룹별로 나누는 단계</span></strong>
- 나누어진 그룹에서 <strong><span style = "color:red">집계 함수(sum, mean, max 등)를 수행</span></strong>하는 단계

[##_Image|t/cfile@99D77D385D6BCF272C|alignCenter|width="900" height="546" data-origin-width="0" data-origin-height="0" data-ke-mobilestyle="widthContent"|||_##]

Library import

```python
import pandas as pd
from pandas import Series , DataFrame
import numpy as np
```

```python
player = pd.read_csv('data/Ch10_1_fifaStats2.csv')
player.head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Name</th>
      <th>Age</th>
      <th>Nationality</th>
      <th>Club</th>
      <th>Preferred Foot</th>
      <th>Crossing</th>
      <th>Dribbling</th>
      <th>LongPassing</th>
      <th>ShotPower</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>L. Messi</td>
      <td>31</td>
      <td>Argentina</td>
      <td>FC Barcelona</td>
      <td>Left</td>
      <td>84.0</td>
      <td>97.0</td>
      <td>87.0</td>
      <td>85.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Cristiano Ronaldo</td>
      <td>33</td>
      <td>Portugal</td>
      <td>Juventus</td>
      <td>Right</td>
      <td>84.0</td>
      <td>88.0</td>
      <td>77.0</td>
      <td>95.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Neymar Jr</td>
      <td>26</td>
      <td>Brazil</td>
      <td>Paris Saint-Germain</td>
      <td>Right</td>
      <td>79.0</td>
      <td>96.0</td>
      <td>78.0</td>
      <td>80.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>De Gea</td>
      <td>27</td>
      <td>Spain</td>
      <td>Manchester United</td>
      <td>Right</td>
      <td>17.0</td>
      <td>18.0</td>
      <td>51.0</td>
      <td>31.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>K. De Bruyne</td>
      <td>27</td>
      <td>Belgium</td>
      <td>Manchester City</td>
      <td>Right</td>
      <td>93.0</td>
      <td>86.0</td>
      <td>91.0</td>
      <td>91.0</td>
    </tr>
  </tbody>
</table>
</div>

### 9.1.1 그룹핑 한줄로 수행하기

<strong><span style = "color:red">팀별</span></strong>로 <strong><span style = "color:red">선수의 능력치</span></strong>에 대한 <strong><span style = "color:red">평균값</span></strong> 확인(최상위 5개 팀 조회)

```python
spByTeam = player.groupby('Club').mean()
spByTeam.sort_values(by = 'LongPassing', ascending = False).head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Crossing</th>
      <th>Dribbling</th>
      <th>LongPassing</th>
      <th>ShotPower</th>
    </tr>
    <tr>
      <th>Club</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Chelsea</th>
      <td>25.212121</td>
      <td>59.484848</td>
      <td>65.666667</td>
      <td>65.787879</td>
      <td>64.060606</td>
    </tr>
    <tr>
      <th>FC Barcelona</th>
      <td>23.848485</td>
      <td>59.818182</td>
      <td>66.121212</td>
      <td>65.727273</td>
      <td>64.303030</td>
    </tr>
    <tr>
      <th>Manchester United</th>
      <td>24.757576</td>
      <td>62.242424</td>
      <td>66.878788</td>
      <td>65.727273</td>
      <td>66.151515</td>
    </tr>
    <tr>
      <th>Manchester City</th>
      <td>23.909091</td>
      <td>59.696970</td>
      <td>66.151515</td>
      <td>65.727273</td>
      <td>65.606061</td>
    </tr>
    <tr>
      <th>Paris Saint-Germain</th>
      <td>24.566667</td>
      <td>63.133333</td>
      <td>68.833333</td>
      <td>65.500000</td>
      <td>64.500000</td>
    </tr>
  </tbody>
</table>
</div>

<strong><u>특정 하나의 컬럼만 조회하기(Series로 결과 출력됨)</u></strong>  
<strong><span style = "color:red">팀별</span></strong>로 <strong><span style = "color:red">Shotpower</span></strong>의 <strong><span style = "color:red">평균</span></strong>을 계산하여 평균값이 제일 높은 5개 팀 조회

```python
spByTeam2 = player.groupby('Club')['ShotPower'].mean()
spByTeam2.sort_values(ascending = False).head()
```

```text
Club
Juventus          68.000000
Ajax              67.400000
Olympiacos CFP    67.000000
SL Benfica        66.714286
Lazio             66.687500
Name: ShotPower, dtype: float64
```

<strong><u>특정 두 개 이상의 컬럼 조회(DataFrame으로 결과 출력됨)</u></strong>  
<strong><span style = "color:red">팀별</span></strong>로 <strong><span style = "color:red">롱패스와 드리블</span></strong> 능력치 <strong><span style = "color:red">평균값</span></strong> 계산하여 최상위 5개 팀 조회

```python
spByTeam3 = player.groupby('Club')[['LongPassing', 'Dribbling']].mean()
spByTeam3.sort_values(by = 'LongPassing', ascending = False).head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LongPassing</th>
      <th>Dribbling</th>
    </tr>
    <tr>
      <th>Club</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Chelsea</th>
      <td>65.787879</td>
      <td>65.666667</td>
    </tr>
    <tr>
      <th>FC Barcelona</th>
      <td>65.727273</td>
      <td>66.121212</td>
    </tr>
    <tr>
      <th>Manchester United</th>
      <td>65.727273</td>
      <td>66.878788</td>
    </tr>
    <tr>
      <th>Manchester City</th>
      <td>65.727273</td>
      <td>66.151515</td>
    </tr>
    <tr>
      <th>Paris Saint-Germain</th>
      <td>65.500000</td>
      <td>68.833333</td>
    </tr>
  </tbody>
</table>
</div>

<strong><u>두 개 이상의 변수로 그룹핑(Multi Index로 결과 조회됨)</u></strong>  
<strong><span style = "color:red">팀 + 나라</span></strong>로 그룹핑하여 <strong><span style = "color:red">롱패스와 드리블</span></strong> 능력치 <strong><span style = "color:red">평균값</span></strong> 최상위 5개 팀+나라 조회

```python
spByTeam4 = player.groupby(['Nationality','Club'])[['LongPassing', 'Dribbling']].mean()
spByTeam4.sort_values(by= 'LongPassing', ascending = False).head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>LongPassing</th>
      <th>Dribbling</th>
    </tr>
    <tr>
      <th>Nationality</th>
      <th>Club</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Germany</th>
      <th>Real Madrid</th>
      <td>93.0</td>
      <td>81.0</td>
    </tr>
    <tr>
      <th>Croatia</th>
      <th>FC Barcelona</th>
      <td>90.0</td>
      <td>84.0</td>
    </tr>
    <tr>
      <th>Denmark</th>
      <th>Tottenham Hotspur</th>
      <td>88.0</td>
      <td>84.0</td>
    </tr>
    <tr>
      <th>Croatia</th>
      <th>Real Madrid</th>
      <td>88.0</td>
      <td>90.0</td>
    </tr>
    <tr>
      <th>Argentina</th>
      <th>FC Barcelona</th>
      <td>87.0</td>
      <td>97.0</td>
    </tr>
  </tbody>
</table>
</div>

### 9.1.2 groupby 원리 파헤치기

#### 9.1.2.1 groupby 함수를 이용하면 Groupby 객체가 생성됨

```python
playerGroup = player.groupby('Club')
playerGroup
```

```text
<pandas.core.groupby.generic.DataFrameGroupBy object at 0x000002211EE1F940>
```

groupby 객체에서 <strong><span style = "color:red">groups 함수</span></strong>를 이용해 그룹별로 나누어진 값을 <strong><u>dict형태(key와 values)</u></strong>로 확인 가능

```python
playerGroup.groups
```

```text
{' SSV Jahn Regensburg': Int64Index([ 4587,  4840,  5260,  5335,  6184,  6783,  6917,  6954,  7184,
              7195,  7633,  7657,  7867,  8337,  8933,  9024,  9212, 10285,
              10312, 10686, 11059, 11244, 11861, 12363, 12671, 14161, 14319,
              16105, 17786],
            dtype='int64'),
  '1. FC Heidenheim 1846': Int64Index([ 2053,  4348,  4812,  5093,  5722,  6135,  6208,  6294,  6333,
              6545,  6678,  7595,  7723,  8543,  8567,  9040,  9380,  9535,
              9890, 12004, 12350, 12356, 12654, 14737, 15318, 15842, 16503,
              17538],
            dtype='int64'),
  '1. FC Kaiserslautern': Int64Index([ 5084,  5445,  6372,  7728,  8550,  9335,  9487,  9554,  9563,
              9812,  9886, 10211, 10469, 10554, 11029, 11091, 12485, 14037,
              14758, 15230, 15285, 15392, 15951, 16788, 17268, 17524],
            dtype='int64'),
  ......
```

#### 9.1.2.2 groupby 객체를 이용해 집계함수 사용

- <strong>하나</strong>의 집계 함수 적용 : <span class = "hlblock">groupby객체.집계함수명()</span>
- <strong>여러개</strong>의 집계 함수 적용 : <span class = "hlblock">groupby객체.agg([집계함수명1,집계함수명2]) 사용</span>(Multi Column 형태로 출력됨)

groupby 객체의 mean 함수 호출

```python
playerGroup.mean().head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Crossing</th>
      <th>Dribbling</th>
      <th>LongPassing</th>
      <th>ShotPower</th>
    </tr>
    <tr>
      <th>Club</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>SSV Jahn Regensburg</th>
      <td>25.655172</td>
      <td>47.172414</td>
      <td>52.655172</td>
      <td>45.689655</td>
      <td>54.137931</td>
    </tr>
    <tr>
      <th>1. FC Heidenheim 1846</th>
      <td>24.000000</td>
      <td>49.464286</td>
      <td>54.214286</td>
      <td>48.964286</td>
      <td>57.071429</td>
    </tr>
    <tr>
      <th>1. FC Kaiserslautern</th>
      <td>23.846154</td>
      <td>48.076923</td>
      <td>49.769231</td>
      <td>48.653846</td>
      <td>56.692308</td>
    </tr>
    <tr>
      <th>1. FC Köln</th>
      <td>24.321429</td>
      <td>52.357143</td>
      <td>57.964286</td>
      <td>54.714286</td>
      <td>58.178571</td>
    </tr>
    <tr>
      <th>1. FC Magdeburg</th>
      <td>24.692308</td>
      <td>46.500000</td>
      <td>51.346154</td>
      <td>47.153846</td>
      <td>52.269231</td>
    </tr>
  </tbody>
</table>
</div>

```python
playerGroup.agg(['mean', 'sum']).head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th colspan="2" halign="left">Age</th>
      <th colspan="2" halign="left">Crossing</th>
      <th colspan="2" halign="left">Dribbling</th>
      <th colspan="2" halign="left">LongPassing</th>
      <th colspan="2" halign="left">ShotPower</th>
    </tr>
    <tr>
      <th></th>
      <th>mean</th>
      <th>sum</th>
      <th>mean</th>
      <th>sum</th>
      <th>mean</th>
      <th>sum</th>
      <th>mean</th>
      <th>sum</th>
      <th>mean</th>
      <th>sum</th>
    </tr>
    <tr>
      <th>Club</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>SSV Jahn Regensburg</th>
      <td>25.655172</td>
      <td>744</td>
      <td>47.172414</td>
      <td>1368.0</td>
      <td>52.655172</td>
      <td>1527.0</td>
      <td>45.689655</td>
      <td>1325.0</td>
      <td>54.137931</td>
      <td>1570.0</td>
    </tr>
    <tr>
      <th>1. FC Heidenheim 1846</th>
      <td>24.000000</td>
      <td>672</td>
      <td>49.464286</td>
      <td>1385.0</td>
      <td>54.214286</td>
      <td>1518.0</td>
      <td>48.964286</td>
      <td>1371.0</td>
      <td>57.071429</td>
      <td>1598.0</td>
    </tr>
    <tr>
      <th>1. FC Kaiserslautern</th>
      <td>23.846154</td>
      <td>620</td>
      <td>48.076923</td>
      <td>1250.0</td>
      <td>49.769231</td>
      <td>1294.0</td>
      <td>48.653846</td>
      <td>1265.0</td>
      <td>56.692308</td>
      <td>1474.0</td>
    </tr>
    <tr>
      <th>1. FC Köln</th>
      <td>24.321429</td>
      <td>681</td>
      <td>52.357143</td>
      <td>1466.0</td>
      <td>57.964286</td>
      <td>1623.0</td>
      <td>54.714286</td>
      <td>1532.0</td>
      <td>58.178571</td>
      <td>1629.0</td>
    </tr>
    <tr>
      <th>1. FC Magdeburg</th>
      <td>24.692308</td>
      <td>642</td>
      <td>46.500000</td>
      <td>1209.0</td>
      <td>51.346154</td>
      <td>1335.0</td>
      <td>47.153846</td>
      <td>1226.0</td>
      <td>52.269231</td>
      <td>1359.0</td>
    </tr>
  </tbody>
</table>
</div>

## 9.2 pivot_table 함수

<span class = "hlblock>player.pivot_table(index, columns, values, aggfunc)</span>

- <strong><u>index</u></strong> : 출력에 사용할 index(그루핑 대상 컬럼)
- <strong><u>columns</u></strong> : 출력에 사용할 columns
- <strong><u>values</u></strong> : 집계함수를 적용할 컬럼명
- <strong><u>aggfunc</u></strong> : 사용할 집계 함수, 여러 개 사용할 경우 [] 안에 집계함수 리스트 작성

EX) <strong><span style="color:red">팀별</span></strong>로 <strong><span style="color:red">드리블 능력치</span></strong>의 <strong><span style="color:red">평균</span></strong>을 구해 상위 5개팀 출력

```python
player.pivot_table(index = 'Club', values = 'Dribbling', aggfunc = 'mean').sort_values(by = 'Dribbling', ascending = False).head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Dribbling</th>
    </tr>
    <tr>
      <th>Club</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Juventus</th>
      <td>69.520000</td>
    </tr>
    <tr>
      <th>Paris Saint-Germain</th>
      <td>68.833333</td>
    </tr>
    <tr>
      <th>Napoli</th>
      <td>68.640000</td>
    </tr>
    <tr>
      <th>Liverpool</th>
      <td>68.212121</td>
    </tr>
    <tr>
      <th>Borussia Dortmund</th>
      <td>68.151515</td>
    </tr>
  </tbody>
</table>
</div>

EX2) <strong><span style="color:red">나라 + 팀</span></strong> 별로 <strong><span style="color:red">롱패스와 슟파워</span></strong>의 <strong><span style="color:red">평균과 최대값</span></strong>을 계산

```python
player.pivot_table(index = ('Nationality','Club'), values = ('LongPassing','ShotPower'), aggfunc = ('mean','max')).head()
```

<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }

</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th></th>
      <th colspan="2" halign="left">LongPassing</th>
      <th colspan="2" halign="left">ShotPower</th>
    </tr>
    <tr>
      <th></th>
      <th></th>
      <th>max</th>
      <th>mean</th>
      <th>max</th>
      <th>mean</th>
    </tr>
    <tr>
      <th>Nationality</th>
      <th>Club</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="4" valign="top">Afghanistan</th>
      <th>Notts County</th>
      <td>60.0</td>
      <td>60.0</td>
      <td>60.0</td>
      <td>60.0</td>
    </tr>
    <tr>
      <th>Philadelphia Union</th>
      <td>59.0</td>
      <td>59.0</td>
      <td>61.0</td>
      <td>61.0</td>
    </tr>
    <tr>
      <th>SV Meppen</th>
      <td>42.0</td>
      <td>42.0</td>
      <td>39.0</td>
      <td>39.0</td>
    </tr>
    <tr>
      <th>Walsall</th>
      <td>55.0</td>
      <td>55.0</td>
      <td>55.0</td>
      <td>55.0</td>
    </tr>
    <tr>
      <th>Albania</th>
      <th>AC Ajaccio</th>
      <td>61.0</td>
      <td>61.0</td>
      <td>69.0</td>
      <td>69.0</td>
    </tr>
  </tbody>
</table>
</div>

위의 Jupyter notebook 내용은 [여기](https://github.com/psyssai/PandasBasic/blob/master/PandasBasic_9_DataFrame_GroupingFunction.ipynb) Github에서도 확인 할 수 있습니다.

감사합니다.
